ZYLORACLOUD Blueprint packages
================================

Upload this ZIP to the root of your GitHub repository, or extract it and upload
the themes/ and extensions/ folders while preserving their structure.

themes/
  nebula.blueprint
  snowflakes.blueprint

extensions/
  sagaautosuspension.blueprint
  playerlisting.blueprint
  huxregister.blueprint
  minecraftpluginmanager.blueprint
  mcplugins.blueprint
  minecraftplayermanager.blueprint
  mclogs.blueprint

These are the uploaded package files, included unchanged. Check each package's
author documentation, license, dependencies, and exact Blueprint compatibility
before installing. Back up the Panel files and database first. Do not force
install packages when their target Blueprint release does not match the server.
